/*
 * Plugin made by Lixqa Development.
 * Do not share the source code
 * Website: https://lix.qa/
 * Discord: https://discord.gg/ldev
 * */

package dev.lixqa.amethystControl;

import dev.lixqa.amethystControl.commands.ClaimAreaCommand;
import dev.lixqa.amethystControl.commands.RedeemAllCommand;
import dev.lixqa.amethystControl.commands.RedeemCommand;
import dev.lixqa.amethystControl.commands.SpawnCrystalsCommand;
import dev.lixqa.amethystControl.commands.SupplyCommand;
import dev.lixqa.amethystControl.listeners.CrystalLifecycleListener;
import dev.lixqa.amethystControl.listeners.FortuneListener;
import dev.lixqa.amethystControl.listeners.GrowthListener;
import org.bukkit.NamespacedKey;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;

public final class AmethystControl extends JavaPlugin {
    private static AmethystControl instance;
    private MintLedger ledger;
    private NamespacedKey mintedCrystalKey;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        ledger = new MintLedger(this);

        try {
            ledger.initialize();
        } catch (MintLedger.LedgerException exception) {
            getLogger().severe("Failed to initialize the crystal ledger: " + exception.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        mintedCrystalKey = new NamespacedKey(this, "minted-crystal");

        getServer().getPluginManager().registerEvents(new FortuneListener(this, ledger, mintedCrystalKey), this);
        getServer().getPluginManager().registerEvents(new CrystalLifecycleListener(this, ledger, mintedCrystalKey), this);
        getServer().getPluginManager().registerEvents(new GrowthListener(), this);
        Objects.requireNonNull(getCommand("claimarea"), "claimarea command not registered").setExecutor(new ClaimAreaCommand(this, ledger));
        Objects.requireNonNull(getCommand("spawncrystals"), "spawncrystals command not registered").setExecutor(new SpawnCrystalsCommand(ledger));
        Objects.requireNonNull(getCommand("supply"), "supply command not registered").setExecutor(new SupplyCommand(this, ledger));
        Objects.requireNonNull(getCommand("redeem"), "redeem command not registered").setExecutor(new RedeemCommand(this, ledger, mintedCrystalKey));
        Objects.requireNonNull(getCommand("redeemall"), "redeemall command not registered").setExecutor(new RedeemAllCommand(this, ledger, mintedCrystalKey));
    }

    @Override
    public void onDisable() {
        if (ledger != null) {
            ledger.close();
        }
    }

    public static AmethystControl getInstance() {
        return instance;
    }

    public MintLedger getLedger() {
        return ledger;
    }

    public NamespacedKey getMintedCrystalKey() {
        return mintedCrystalKey;
    }
}
